//export const DOMAIN_ADDRESS = 'http://localhost:8888/foodicted-api/';
// export const DOMAIN_ADDRESS = 'http://50.0.0.14:3000/';
// export const API_URL = 'http://50.0.0.14:3000/';
export const DOMAIN_ADDRESS = 'http://32635e0c.ngrok.io/';
export const API_URL = 'http://32635e0c.ngrok.io/';
